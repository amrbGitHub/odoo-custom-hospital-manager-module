from odoo import models, fields, api

class Patient(models.Model):
    _name = 'hospital.patient'
    _description = 'Hospital Patient'
    _inherit =  ['mail.thread', 'mail.activity.mixin']

    partner_id = fields.Many2one('res.partner', string='Customer', required=False)

    name = fields.Char(string='Name', required=True, tracking=True)
    age = fields.Integer(string='Age', tracking=True)
    gender = fields.Selection([
        ('male', 'Male'),
        ('female', 'Female'),
        ('other', 'Other'),
    ], string='Gender', tracking=True)
    address = fields.Text(string='Address',tracking=True)
    phone = fields.Char(string='Phone',tracking=True)
    email = fields.Char(string='Email', tracking=True)
    blood_type = fields.Selection([
        ('A+', 'A+'),
        ('A-', 'A-'),
        ('B+', 'B+'),
        ('B-', 'B-'),
        ('AB+', 'AB+'),
        ('AB-', 'AB-'),
        ('O+', 'O+'),
        ('O-', 'O-'),
    ], string='Blood Type')
    medical_history = fields.Text(string='Medical History')
    active = fields.Boolean(string='Active', default=True)
