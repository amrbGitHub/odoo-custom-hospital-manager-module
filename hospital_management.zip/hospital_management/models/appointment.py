from odoo import models, fields, api
from datetime import datetime

class Appointment(models.Model):
    _name = 'hospital.appointment'
    _description = 'Hospital Appointment'
    _inherit =  ['mail.thread', 'mail.activity.mixin']

    patient_id = fields.Many2one('hospital.patient', string='Patient', required=True, tracking=True)
    doctor_id = fields.Many2one('hospital.doctor', string='Doctor', required=True, tracking=True)
    appointment_date = fields.Datetime(string='Appointment Date', default=fields.Datetime.now, tracking=True)
    appointment_end = fields.Datetime(string='Appointment End', tracking=True)
    state = fields.Selection([
        ('draft', 'Draft'),
        ('confirmed', 'Confirmed'),
        ('done', 'Done'),
        ('canceled', 'Canceled'),
    ], string='Status', default='draft', tracking=True)
    notes = fields.Text(string='Notes', tracking=True)

    sale_order_id = fields.Many2one(
        'sale.order', string="Related Quotation", readonly=True, copy=False
    )
    # override write
    def write(self,vals):
        res = super().write(vals)
        for rec in self:
            if rec.state == "confirmed" and not rec.sale_order_id:
                rec._create_sale_order()
        return res
    
    # Quotation creation helper
    def _create_sale_order(self):
        #Create new sale oder when appointment is confirmed
        SaleOrder = self.env['sale.order']

        #Ensure patient is linked to res.partner
        if not self.patient_id.partner_id:
            partner_vals = {
                "name": self.patient_id.name,
                "phone": self.patient_id.phone if hasattr(self.patient_id, "phone") else False,
                "email": self.patient_id.email if hasattr(self.patient_id, "email") else False,
                "customer_rank": 1, # Mark as customer
            }
            partner = self.env["res.partner"].create(partner_vals)
            self.patient_id.partner_id = partner.id
        
        
        #Ensure you have a consultation product aka "Product data"
        product = self.env.ref("hospital_management.product_appointment", raise_if_not_found=False)
        if not product:
            raise ValueError("Define a consultation product to use in quotations")
        order_vals = {
            "partner_id": self.patient_id.partner_id.id,
            "origin": f"Appointment #{self.id}",
            "order_line":[(0,0,{
                "name":f"Appointment with {self.doctor_id.name}",
                "product_id": product.id,
                "product_uom_qty" : 1,
                "price_unit": product.lst_price,
            })],
        }

        sale_order = SaleOrder.create(order_vals)
        self.sale_order_id = sale_order.id
        self._send_confirmation_email()

        # Send Appointment confirmation email to patient
    def _send_confirmation_email(self):
        self.ensure_one()
        template = self.env.ref('hospital_management.email_template_appointment_confirmation')
        template.send_mail(self.id, force_send=True)
        