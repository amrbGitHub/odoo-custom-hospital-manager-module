{
    'name': 'Hospital Manager',
    'summary' : 'A module for managing a hospital',
    'author'  : 'Amro Belbeisi',
    'version' : '1.5',
    'license' : 'GPL-3',
    'category': 'Medical',
    'depends' : [
        'base', 'mail', 'sale', 'contacts'
    ],
    'data': [
        'security/ir.model.access.csv',
        'data/product_data.xml',
        'data/email_templates.xml',
        'views/patient_views.xml',
        'views/doctor_views.xml',
        'views/appointment_views.xml',
        'views/department_views.xml',
        'views/ticket_views.xml',
        'views/menu_views.xml',
        
    ],
    'application' : True
}
