from . import appointment
from . import doctor
from . import patient
from . import department
from . import ticket