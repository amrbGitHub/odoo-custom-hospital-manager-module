from odoo import models, fields, api
from odoo.tools import html2plaintext
import re
class HospitalTicket(models.Model):
    _name = 'hospital.ticket'
    _description = 'Patient Email Ticket'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    name = fields.Char(string="Subject", tracking=True)
    patient_email = fields.Char(string="Patient Email", tracking=True)
    patient_name = fields.Char(string="Patient Name", tracking=True)
    description = fields.Text(string="Message", tracking=True)
    patient_id = fields.Many2one('hospital.patient')
    partner_id = fields.Many2one('res.partner', string="Related Contact")
    state = fields.Selection([
        ('new', 'New'),
        ('in_progress', 'In Progress'),
        ('done', 'Resolved')
    ], string="Status", default='new', tracking=True)
  
    @api.model
    def message_new(self, msg, custom_values=None):
        # Split 'from' section of email into two strings (email, name of sender)
        patient_email = msg.get('from')
        match = re.match(r'"(.+)"\s+<(.+)>', patient_email)
        if match:
            name,email = match.groups()

        # Create contact if not linked
        partner = self.env['res.partner'].search([('email', '=', email)], limit=1)
        if not partner:
            partner = self.env['res.partner'].create({
                'name': name or email,
                'email': email,
                'is_company' : False,
                'type' : 'contact'
            })
        # Create the customer as a patient if they are not already
        patient = self.env['hospital.patient'].search([('email', '=', email)], limit=1)
        if not patient:
            patient = self.env['hospital.patient'].create({
                'name': name,
                'email': email,
            })
        # Create tickets automatically from incoming emails
        vals = {
            'name': msg.get('subject', 'No Subject'),
            'patient_email': email,
            'patient_name' : name,
            'description': html2plaintext(msg.get('body', '')), 
        }
        vals.update(custom_values or {})

       
      

    
        return super(HospitalTicket, self).create(vals)

    
