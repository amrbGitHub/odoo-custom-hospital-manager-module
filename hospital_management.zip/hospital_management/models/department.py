from odoo import models, fields, api

class Department(models.Model):
    _name = 'hospital.department'
    _description = 'Hospital Department'
    _inherit =  ['mail.thread', 'mail.activity.mixin']

    name = fields.Char(string='Name', required=True, tracking=True)
    code = fields.Char(string='Code',tracking=True)
    description = fields.Text(string='Description', tracking=True)
    active = fields.Boolean(string='Active', default=True, tracking=True)