from odoo import models, fields, api

class Doctor(models.Model):
    _name = 'hospital.doctor'
    _description = 'Hospital Doctor'
    _inherit =  ['mail.thread', 'mail.activity.mixin']

    name = fields.Char(string='Name', required=True, tracking=True)
    specialty = fields.Char(string='Specialty')
    department_id = fields.Many2one('hospital.department', string='Department', tracking=True)
    phone = fields.Char(string='Phone', tracking=True)
    email = fields.Char(string='Email', tracking=True)
    active = fields.Boolean(string='Active', default=True, tracking=True)